
int asciiBinaryToInt(char *s);

int asciiHEXToInt(char *s);

double asciiToDouble(char *s);
